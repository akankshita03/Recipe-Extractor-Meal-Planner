def generate_recipe_data(text):
    return {
        "title": "Grilled Cheese Sandwich",
        "cuisine": "American",
        "prep_time": "5 mins",
        "cook_time": "10 mins",
        "total_time": "15 mins",
        "servings": 2,
        "difficulty": "easy",
        "ingredients": [
            {"quantity": "2", "unit": "slices", "item": "bread"},
            {"quantity": "1", "unit": "tbsp", "item": "butter"}
        ],
        "instructions": ["Heat pan", "Add butter", "Toast bread"],
        "nutrition_estimate": {
            "calories": 300,
            "protein": "10g",
            "carbs": "30g",
            "fat": "15g"
        },
        "substitutions": [
            "Use olive oil instead of butter",
            "Use wheat bread",
            "Use vegan cheese"
        ],
        "shopping_list": {
            "dairy": ["butter"],
            "bakery": ["bread"]
        },
        "related_recipes": ["Tomato Soup", "Sandwich", "Toast"]
    }
