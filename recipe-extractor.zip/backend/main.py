from fastapi import FastAPI
from database import Base, engine, SessionLocal
from models import Recipe
from scraper import scrape_recipe
from llm import generate_recipe_data
import json

Base.metadata.create_all(bind=engine)

app = FastAPI()

@app.post("/extract")
def extract_recipe(url: str):
    raw_text = scrape_recipe(url)
    data = generate_recipe_data(raw_text)

    db = SessionLocal()
    recipe = Recipe(
        url=url,
        title=data["title"],
        cuisine=data["cuisine"],
        difficulty=data["difficulty"],
        data=json.dumps(data)
    )
    db.add(recipe)
    db.commit()
    db.refresh(recipe)

    return {"id": recipe.id, **data}

@app.get("/recipes")
def get_recipes():
    db = SessionLocal()
    recipes = db.query(Recipe).all()
    return [{"id": r.id, "title": r.title, "cuisine": r.cuisine, "difficulty": r.difficulty} for r in recipes]

@app.get("/recipes/{recipe_id}")
def get_recipe(recipe_id: int):
    db = SessionLocal()
    recipe = db.query(Recipe).filter(Recipe.id == recipe_id).first()
    return json.loads(recipe.data)
