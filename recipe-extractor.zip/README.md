# Recipe Extractor

## Run
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload

Open frontend/index.html
